I:\Data\Win10LTSC\Arduino\core\wiring_analog.c.o: \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\cores\tiny\wiring_analog.c \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\cores\tiny\wiring_private.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\cores\tiny\Arduino.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\cores\tiny\binary.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\variants\tinyX4_reverse/pins_arduino.h
