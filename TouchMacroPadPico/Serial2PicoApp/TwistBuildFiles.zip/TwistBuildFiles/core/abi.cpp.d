I:\Data\Win10LTSC\Arduino\core\abi.cpp.o: \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\cores\tiny\abi.cpp
