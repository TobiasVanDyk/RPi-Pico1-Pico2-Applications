I:\Data\Win10LTSC\Arduino\sketch\Qwiic_Twist.ino.cpp.o: \
 I:\Data\Win10LTSC\Arduino\sketch\Qwiic_Twist.ino.cpp \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\cores\tiny/Arduino.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\cores\tiny/binary.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\variants\tinyX4_reverse/pins_arduino.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\cores\tiny/WCharacter.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\cores\tiny/WString.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\cores\tiny/HardwareSerial.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\cores\tiny/TinySoftwareSerial.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\cores\tiny/Stream.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\cores\tiny/Print.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\libraries\Wire\src/Wire.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\libraries\EEPROM/EEPROM.h \
 I:\Data\Win10LTSC\Arduino\sketch\nvm.h \
 C:\Users\Tobias\Documents\Arduino\libraries\PinChangeInterrupt\src/PinChangeInterrupt.h \
 C:\Users\Tobias\Documents\Arduino\libraries\PinChangeInterrupt\src/PinChangeInterruptSettings.h \
 C:\Users\Tobias\Documents\Arduino\libraries\PinChangeInterrupt\src/PinChangeInterruptBoards.h \
 C:\Users\Tobias\Documents\Arduino\libraries\PinChangeInterrupt\src/PinChangeInterruptPins.h
