I:\Data\Win10LTSC\Arduino\libraries\Wire\USI_TWI_Master\USI_TWI_Master.c.o: \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\libraries\Wire\src\USI_TWI_Master\USI_TWI_Master.c \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\libraries\Wire\src\USI_TWI_Master\USI_TWI_Master.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\variants\tinyX4_reverse/pins_arduino.h
