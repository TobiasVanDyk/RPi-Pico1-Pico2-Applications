I:\Data\Win10LTSC\Arduino\libraries\Wire\USIWire.cpp.o: \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\libraries\Wire\src\USIWire.cpp
