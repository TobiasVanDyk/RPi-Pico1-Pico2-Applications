I:\Data\Win10LTSC\Arduino\libraries\Wire\USI_TWI_Slave\USI_TWI_Slave.c.o: \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\libraries\Wire\src\USI_TWI_Slave\USI_TWI_Slave.c \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\libraries\Wire\src\USI_TWI_Slave\USI_TWI_Slave.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\variants\tinyX4_reverse/pins_arduino.h
