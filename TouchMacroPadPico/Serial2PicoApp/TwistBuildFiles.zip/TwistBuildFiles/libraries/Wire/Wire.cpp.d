I:\Data\Win10LTSC\Arduino\libraries\Wire\Wire.cpp.o: \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\libraries\Wire\src\Wire.cpp \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\libraries\Wire\src\USI_TWI_Slave/USI_TWI_Slave.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\variants\tinyX4_reverse/pins_arduino.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\libraries\Wire\src\USI_TWI_Master/USI_TWI_Master.h \
 C:\Users\Tobias\AppData\Local\Arduino15\packages\ATTinyCore\hardware\avr\1.3.3\libraries\Wire\src\Wire.h
